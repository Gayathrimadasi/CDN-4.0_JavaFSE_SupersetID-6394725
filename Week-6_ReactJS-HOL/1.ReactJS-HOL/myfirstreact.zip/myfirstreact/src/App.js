import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <centre><h1>Welcome the first session of React</h1></centre>
  );
}

export default App;
