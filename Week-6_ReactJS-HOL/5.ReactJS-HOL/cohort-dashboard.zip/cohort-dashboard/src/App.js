import React from 'react';
import CohortDetails from './CohortDetails';
import './App.css'; // optional, if you want to style heading/app layout

function App() {
  const cohorts = [
    {
      name: 'React Bootcamp',
      status: 'ongoing',
      startDate: '2025-07-01',
      endDate: '2025-08-30',
    },
    {
      name: 'Java Fullstack',
      status: 'completed',
      startDate: '2025-05-01',
      endDate: '2025-06-30',
    },
    {
      name: 'Python for Data Science',
      status: 'ongoing',
      startDate: '2025-07-15',
      endDate: '2025-09-10',
    },
    {
      name: 'AWS Cloud Training',
      status: 'completed',
      startDate: '2025-04-01',
      endDate: '2025-05-31',
    },
    {
      name: 'DevOps Foundation',
      status: 'completed',
      startDate: '2025-03-01',
      endDate: '2025-04-15',
    },
  ];

  return (
    <div className="App">
      <h1 style={{ textAlign: 'center', color: '#333' }}>
        My Academy Cohort Dashboard
      </h1>
      <div style={{ textAlign: 'center' }}>
        {cohorts.map((cohort, index) => (
          <CohortDetails key={index} cohort={cohort} />
        ))}
      </div>
    </div>
  );
}

export default App;
