import React from 'react';

function WelcomeButton() {
  const sayWelcome = (message) => {
    alert(message);
  };

  return (
    <div>
      <button onClick={() => sayWelcome('welcome')}>Say welcome</button>
    </div>
  );
}

export default WelcomeButton;
