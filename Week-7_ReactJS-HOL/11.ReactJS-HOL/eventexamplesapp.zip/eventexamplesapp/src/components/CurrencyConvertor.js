import React, { useState } from 'react';

function CurrencyConvertor() {
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    let converted = amount * 80; // Assuming 1 Euro = ₹80
    if (currency.toLowerCase() === "euro") {
      alert(`Converting to  Euro Amount is ${converted}`);
    } else {
      alert("Currency not supported");
    }
  };

  return (
    <div>
      <h2 style={{ color: "green", fontWeight: "bold" }}>Currency Convertor!!!</h2>
      <form onSubmit={handleSubmit}>
        <label>Amount: </label>
        <input
          type="text"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        /><br />

        <label>Currency: </label>
        <textarea
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
        ></textarea><br />

        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default CurrencyConvertor;
