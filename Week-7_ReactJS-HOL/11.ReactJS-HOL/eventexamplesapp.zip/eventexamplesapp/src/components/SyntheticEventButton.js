import React from 'react';

function SyntheticEventButton() {
  const handleClick = (e) => {
    alert("I was clicked");
    console.log(e); // Synthetic event
  };

  return (
    <div>
      <button onClick={handleClick}>Click on me</button>
    </div>
  );
}

export default SyntheticEventButton;
