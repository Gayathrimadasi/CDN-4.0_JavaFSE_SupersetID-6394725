import React from 'react';

const CourseDetails = () => {
  const showCourse = true; // conditional rendering using logical &&

  return showCourse && (
    <div>
      <h2>Course Details</h2>
      <p><strong>Angular</strong><br />4/5/2021</p>
      <p><strong>React</strong><br />6/3/20201</p>
    </div>
  );
};

export default CourseDetails;
