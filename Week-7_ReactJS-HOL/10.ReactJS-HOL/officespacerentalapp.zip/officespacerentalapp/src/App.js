// src/App.js
import React from 'react';
import './App.css';

function App() {
  const offices = [
    {
      name: "DBS",
      rent: 50000,
      address: "Chennai",
      image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=60",
    },
    {
      name: "WeWork",
      rent: 75000,
      address: "Bangalore",
      image: "https://images.unsplash.com/photo-1590650046871-92c887180603?auto=format&fit=crop&w=800&q=60",
    }
  ];

  return (
    <div className="App">
      <h1>Office Space, at Affordable Range</h1>
      {offices.map((office, index) => (
        <div key={index} className="office-card">
          <img src={office.image} alt={office.name} width="300" height="200" />
          <h2>Name: {office.name}</h2>
          <h3 style={{ color: office.rent < 60000 ? 'red' : 'green' }}>
            Rent: Rs. {office.rent}
          </h3>
          <p><strong>Address:</strong> {office.address}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
