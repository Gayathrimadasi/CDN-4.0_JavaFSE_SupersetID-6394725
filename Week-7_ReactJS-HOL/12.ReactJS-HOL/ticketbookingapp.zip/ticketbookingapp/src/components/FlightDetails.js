import React from 'react';

const FlightDetails = () => {
  return (
    <div>
      <h2>Flight Details</h2>
      <ul>
        <li>Flight: AI202 - Delhi to Mumbai - 10:00 AM</li>
        <li>Flight: AI303 - Mumbai to Bangalore - 12:00 PM</li>
        <li>Flight: AI404 - Chennai to Delhi - 3:00 PM</li>
      </ul>
    </div>
  );
};

export default FlightDetails;
