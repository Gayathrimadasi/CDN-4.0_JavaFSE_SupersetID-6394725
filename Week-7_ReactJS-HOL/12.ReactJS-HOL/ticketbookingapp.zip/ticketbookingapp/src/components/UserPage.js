import React from 'react';
import FlightDetails from './FlightDetails';

const UserPage = ({ onLogout }) => {
  return (
    <div>
      <h1>Welcome back</h1>
      <FlightDetails />
      <p>You can now book your flight tickets.</p>
      <button onClick={onLogout}>Logout</button>
    </div>
  );
};

export default UserPage;
