import React from 'react';
import FlightDetails from './FlightDetails';

const GuestPage = ({ onLogin }) => {
  return (
    <div>
      <h1>Please sign up.</h1>
      <FlightDetails />
      <button onClick={onLogin}>Login</button>
    </div>
  );
};

export default GuestPage;
